/**
 * Lab 5
 * @author Adam Clifton
 * @email akclifto@asu.edu
 */

------------------------------------------------------
ACTIVITY 1: Currency Conversion Calculator
------------------------------------------------------
To start server, run: 

`npm start`

For API documentation please go to localhost:8008/api for information.
There is also a link to it from the home page.

R1: Implemented
R2: Implemented
R3: Implemented
R4: Implemented

------------------------------------------------------
ACTIVITY 2: GitHub API
------------------------------------------------------

SPA with GitHub API fetch calls.  I noticed while developing that GitHub rate limited me after a certain
number of fetch requests, and would then lock me out for about ten minutes before I could make another fetch request.
Not sure if that will be an issue for you, but pointing it out anyway.

Please let me know if you have any issues. 

R1: Implemented
R2: Implemented
R3: Implemented
R4: Implemented
